# Example Package

This package allows to connect to Capture, a data platform used to capture data from industry (https://capture-data.com/en/) from python code